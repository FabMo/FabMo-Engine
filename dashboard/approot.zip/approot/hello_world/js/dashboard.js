var FabMoDashboard = function() {
	this.target = window.parent;
}

FabMoDashboard.prototype.postMessage = function(msg) {
	this.target.postMessage(msg, '*');
}

FabMoDashboard.prototype.showDRO = function() {
	this.postMessage({"showDRO":true});
}

FabMoDashboard.prototype.hideDRO = function() {
	this.postMessage({"showDRO":false});
}


fabmoDashboard = new FabMoDashboard();