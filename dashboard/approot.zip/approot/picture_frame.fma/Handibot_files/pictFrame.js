

$(document).ready(function() {

    $(".canvas-changer").change(function() {
        OnParamChange();
    });

    connectFeedrateControlInteraction();
    connectFrameStyleImageInteraction();
    
    RedrawGeomCanvas();
});    


var connectFrameStyleImageInteraction = function() {

    $("input[name='frameOpeningShape']").change (function() {
        RedrawGeomCanvas();
    });

    $( "label[for='frameShape']" ).mouseover(function() {

        var caller = $(this)[0];
        var callerId = caller.id;

        var imgurl = HA_PictFrame.frameShapeToImg(callerId);
        
        var img = $("img[id='frameShape']")[0];
        img.src = imgurl;
        //img.style.width = '200px';
        //img.style.height = '300px';
        
    });
    
    $( "label[for='frameShape']" ).mouseout(function() {

        var selectedId = document.querySelector('input[name="frameShape"]:checked').value;
        var imgurl = HA_PictFrame.frameShapeToImg(selectedId);
        
        var img = $("img[id='frameShape']")[0];
        img.src = imgurl;
        
    });
}

var connectFeedrateControlInteraction = function() {

    $("#feedrateDropdown").change(function() {
         var fr_val = document.getElementById("feedrateDropdown").value;
         
         if (fr_val != 0) // don't reset custom   
            document.getElementById("feedrate").value = fr_val;         
    });
    
    $("#feedrate").change(function() {
    
         // select the last one, "custom"       
        var fr_dd = $('select#feedrateDropdown');        
        
        var fr_dd_2 = $("#feedrateDropdown");
        fr_dd_2[0].selectedIndex=3;
        
        // foundation builds a custom dropdown, we have to notify it of the cha       
        // http://foundation.zurb.com/docs/v/4.3.2/components/custom-forms.html        
        fr_dd_2.trigger("change", true);
    });
}

var RedrawGeomCanvas = function () {

    var canvas = document.getElementById("app-canvas");
    //var glyphCanvas = document.getElementById("glyph-canvas");
        
    var params = HA_PictFrame.collectParams(document);

    // first erase the canvas
    var ctx = canvas.getContext('2d');
    ctx.save();

    // draw transparent, unfortunately, this seems to set the canvas color to black
    // we compensate by treating transparent as white in acGreyImage.initFromCanvas()
    ctx.clearRect(0, 0, canvas.width, canvas.height); 
    
    ctx.restore();
    
    HA_PictFrame.drawGeom(canvas, params);
    // HA_PictFrame.drawGlyphs(glyphCanvas, params); no glyphs yet
}

var RedrawGlyphCanvas = function () {

    var canvas = document.getElementById("glyph-canvas");
    var params = HA_PictFrame.collectParams(document);

    // first erase the canvas
    var ctx = canvas.getContext('2d');
    ctx.save();

    // draw transparent, unfortunately, this seems to set the canvas color to black
    // we compensate by treating transparent as white in acGreyImage.initFromCanvas()
    ctx.clearRect(0, 0, canvas.width, canvas.height); 
    
    ctx.restore();
    
    HA_PictFrame.drawGlyphs(canvas, params);
}

var OnParamChange = function() {

    RedrawGeomCanvas();
    HA_Utils.clearPathCanvas();
    // RedrawGlyphCanvas(); no glyphs yet
}

var OnDrawPath = function() {

    var params = HA_PictFrame.collectParams(document);
    var toolDiamPx = params.bitDiam * params.pxPerIn ; // in px
    
    HA_Utils.onDrawPath(toolDiamPx, params.pocket);

}

var OnGenGCode = function() {

    var params = HA_PictFrame.collectParams(document);
    var canvas = document.getElementById('app-canvas');
    var path = HA_Utils.buildToolpath(canvas);
    var gCode = HA_PictFrame.genGCode(params, path);
    
    HA_Utils.exportToFile(gCode, "partGCode.nc");
}


onRunFile = function(){
    var params = HA_PictFrame.collectParams(document);
    var canvas = document.getElementById('app-canvas');
    var path = HA_Utils.buildToolpath(canvas);
    var gCode = HA_PictFrame.genGCode(params, path);
    global.tool.run_local_file(gCode,'nc',function(err){
        if(err)console.log('err');
        else console.log('file successfully send');
    });

}

// helper to draw ovals
function drawOval(context, x, y, w, h){
        context.save(); // save state
        context.beginPath();

        context.translate(x, y);
        context.scale(w/2, h/2);
        context.arc(1, 1, 1, 0, 2 * Math.PI, false);

        context.restore(); // restore to original state
        context.fill();
}

HA_PictFrame = {

    findSelectedFrameShape: function() {
        
        // embarassing code, but how is this supposed to be done?
        if (document.getElementById("rectframe").checked)
            return "rect";
        if (document.getElementById("ovalframe").checked)
            return "oval"; 
        if (document.getElementById("concframe").checked)
            return "conc"; 
        if (document.getElementById("knobframe").checked)
            return "knob"; 
        if (document.getElementById("bracframe").checked)
            return "brac";
        if (document.getElementById("heartframe").checked)
            return "heart";    

        alert ("No frame selected");
        return "";
    },

    frameShapeToImg: function(frameShape) {
    
        var img = "";
        switch (frameShape) {
            case "rect":
                img = "images/picture-frame/frame-rectangle-01.svg";
                break;
            case "oval":
                img = "images/picture-frame/frame-oval-02.svg";
                break;
            case "conc":
                img = "images/picture-frame/frame-concave-03.svg";
                break;
            case "knob":
                img = "images/picture-frame/frame-knob-04.svg";
                break;    
            case "brac":
                img = "images/picture-frame/frame-bracket-05.svg";
                break;
            case "heart":
                img = "images/picture-frame/frame-heart-06.svg";
                break; 
            default:
                alert("Unsupported frame style");
                break;
        };
        
        return img;
    },
    
    findSelectedOpeningShape: function() {
        
        // embarassing code, but how is this supposed to be done?
        if (document.getElementById("rectOpening").checked)
            return "rect";
    
        if (document.getElementById("circOpening").checked)
            return "circ";

        alert ("No frame selected");
        return "";
    },

    collectParams: function(doc) {
    
        var yAxisTop = 8.0; // in inches
        var epsilon = .0001; // tolerance for error checking
    
        var res = {};

        res.matDepth = doc.getElementById("matDepth").valueAsNumber;
        
        var fmShp = this.findSelectedFrameShape();
        res.frameShapeImg = this.frameShapeToImg(fmShp);
        
        res.openShp = this.findSelectedOpeningShape(); // string either "rect" or "circ"
        
        res.inchToMm = 25.4; 
        res.bitDiam = doc.getElementById("bitDiam").valueAsNumber;
        res.feedrate = doc.getElementById("feedrate").valueAsNumber; // in/min
        
        if (doc.getElementById("depthPerPass"))
            res.depthPerPass = doc.getElementById("depthPerPass").valueAsNumber;
 
        res.epsilon = epsilon;
        res.pxPerIn = 100;
        
        return res;
    },
    
    // helper that takes an img (e.g. svg with transparent boundary and grey fill) and converts the
    // grey to white. Don't forget that the img should be loaded.
    // this let's me super impose a grey on a white on a black version of the same file
    // grey is 0 to 255
    drawImageGrey: function(ctx, img, x, y, w, h, greyval) {
    
        ctx.drawImage(img, x, y, w, h);
        var imageData = ctx.getImageData(x, y, w, h);
        var data = imageData.data;

        for(var i = 0; i < data.length; i += 4) {
        
            // transparent becomes black (and stays transparent)
            if (data[i+3] < 255) 
            {
                data[i] = data[i+1] = data[i+2] = 255;
            }
            // anything other than black is greyval:
            else if (!(data[i] === 0 && data[i+1] === 0 && data[i+2] === 0)) 
            {
                data[i] = data[i+1] = data[i+2] = greyval;
                //data[i+2] = 255;
            }
        }
        
        ctx.putImageData(imageData, x, y);
    },
    
    drawGeom: function(canvas, params) {
    
        var in2mm = params.inchToMm;
    
        var selOpening = document.querySelector('input[name="frameOpeningShape"]:checked').value;
        var ctx = canvas.getContext('2d');
        ctx.save();

        ctx.fillStyle = "white"; 
        ctx.fillRect(0,0,canvas.width, canvas.height);
        
        ctx.fillStyle = "black"; 
        ctx.beginPath();

        var that = this;
        
        var img = new Image();                
        img.src = params.frameShapeImg;

        img.onload = function() {
            var margin = 60;
            var twomgn = margin*2;
            
            var mgnwid = canvas.width-2*margin;
            var mgnht = canvas.height-2*margin;
            var twomgnwid = canvas.width-2*twomgn;
            var twomgnht = canvas.height-2*twomgn;
            
            ctx.drawImage(img, margin, margin, mgnwid, mgnht);
            
            // now make the image binary
            var imageData = ctx.getImageData(margin, margin, mgnwid, mgnht);
            var data = imageData.data;

            for(var i = 0; i < data.length; i += 4) {
            
                // transparent becomes white (and stays transparent)
                if (data[i+3] < 255) 
                {
                    data[i] = data[i+1] = data[i+2] = 255;
                }
                // anything other than white is black:
                else if (data[i] < 255 || data[i+1] < 255 || data[i+2] < 255) 
                {
                    data[i] = data[i+1] = data[i+2] = 0;
                    //data[i+2] = 255;
                }
            }

            // overwrite original image
            ctx.putImageData(imageData, margin, margin);
            
            that.drawImageGrey(ctx, img, twomgn, twomgn, twomgnwid, twomgnht, 255);
            
            ctx.save();
            ctx.fillStyle = "rgba(128, 128, 128, 255)";
            
            if (selOpening === "rect")
                ctx.fillRect(twomgn+margin, twomgn+margin, twomgnwid-2*margin, twomgnht-2*margin);
            else 
                drawOval(ctx, twomgn+margin, twomgn+margin, twomgnwid-2*margin, twomgnht-2*margin);
            
            
            
            ctx.restore();
            
            // corners are square here, not sure why this doesn't work when the previous call did work
            //that.drawImageGrey(ctx, img, twomgn+margin, twomgn+margin, twomgnwid-2*margin, twomgnht-2*margin, 150);

        }
        
        ctx.fill(); 
        ctx.restore();
    },
    
    genGCode: function(params, path) {
                  
        var gCode = path.generateGCode(1);                       
        return gCode;
    }

}

