HA_Utils = {

    buildToolpath: function(canvas, bitDiamPx) {

        // todo, the args should be reversed to match pocket toolpaths
        var path = buildToolpaths3(bitDiamPx, canvas); 
                
        return path;
    },
    
    buildPocketToolpaths: function(canvas, bitDiamPx) {

        var paths = buildPocketToolpaths(canvas, bitDiamPx); 
        
        return paths;
    },
    
    // draw an array of toolpaths (like from pocketing)
    drawToolpaths: function(paths, canvas) {
    
        var ctx = canvas.getContext('2d');
        ctx.save();
        ctx.strokeStyle = "#FF0000";
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        for (var i = 0; i < paths.length; ++i) {   
        
            var path = paths[i];
            path.drawSimpleSegments(canvas);
        }
        
        ctx.restore();
    },
    
    drawToolpath: function(path, canvas) {
                
        var ctx = canvas.getContext('2d');
        ctx.save();
        ctx.strokeStyle = "#FF0000";
        path.drawSimpleSegments(canvas);
        ctx.restore();
    },

    buildDebugCanvas: function () {
    
        var canvas = document.createElement('canvas');
        canvas.id     = "CursorLayer";
        canvas.width  = 6;
        canvas.height = 6;
        canvas.style.position = "absolute";
        canvas.style.border   = "1px solid";
        document.body.appendChild(canvas);
        
        var ctx = canvas.getContext('2d');
        ctx.fillStyle="#FFFFFF";
        ctx.fillRect(0,0,canvas.width, canvas.height);
        
        // now make one pixel black
        var id = ctx.createImageData(1,1); // only do this once per page
        var d  = id.data;                        // only do this once per page
        d[0]   = 0;
        d[1]   = 0;
        d[2]   = 0;
        d[3]   = 255;
        ctx.putImageData( id, 2, 2 );                
        ctx.putImageData( id, 2, 3 );                
        ctx.putImageData( id, 3, 2 );                
        ctx.putImageData( id, 3, 3 );                

        return canvas;
    },
    
    
    clearGeomCanvas: function() {
        var can = document.getElementById('app-canvas');
        this.clearCanvas(can);
    },
    clearPathCanvas: function() {
        var can = document.getElementById("path-canvas");
        this.clearCanvas(can);
    },
    clearGlyphCanvas: function() {
        var can = document.getElementById("glyph-canvas");
        this.clearCanvas(can);
    },
    
    clearCanvas: function(canvas) {
        var ctx = canvas.getContext('2d');
        ctx.clearRect(0,0,canvas.width, canvas.height);
    },
    
    onDrawPath: function(toolDiamPx, isPocket) {

        //clearPathCanvas();
        //var canvas = document.getElementById('path-canvas');
        var geomCanvas = document.getElementById('app-canvas');
        var pathCanvas = document.getElementById("path-canvas");

        var paths, path;
                    
        if (isPocket) {
       
            paths = this.buildPocketToolpaths(geomCanvas, toolDiamPx);
            this.drawToolpaths(paths, pathCanvas);
        }
        else {
        
            path = this.buildToolpath(geomCanvas, toolDiamPx);
            this.drawToolpath(path, pathCanvas);
        }

        return false;
    },

    exportToFile: function(content, filename) {

        var file = "data:text/csv;charset=utf-8,";
        file += content;
        
        var encodedUri = encodeURI(file);
        var link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", filename);
        
        link.click();
    }
}